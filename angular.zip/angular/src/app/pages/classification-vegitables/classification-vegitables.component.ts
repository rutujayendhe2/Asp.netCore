import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-classification-vegitables',
  templateUrl: './classification-vegitables.component.html',
  styleUrls: ['./classification-vegitables.component.css']
})
export class ClassificationVegitablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
