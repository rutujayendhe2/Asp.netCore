import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frontend-dashboard',
  templateUrl: './frontend-dashboard.component.html',
  styleUrls: ['./frontend-dashboard.component.css']
})
export class FrontendDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
