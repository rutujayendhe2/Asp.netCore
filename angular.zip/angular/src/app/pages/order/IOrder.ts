export interface IOrder{
    id:number;
    fullname:string,
    email:string,
    phone:string,
    city:string,
    zip:string,
    address:string,
    state:string,
    country:string,
    status:string,
    totalprice:number
}